from typing import Tuple, List
from collections import namedtuple
import logging
from pathlib import Path
import sys

PROJECT_ROOT_DIR = Path(__file__).parent.parent.parent
if str(PROJECT_ROOT_DIR.absolute()) not in sys.path:
    sys.path.append(str(PROJECT_ROOT_DIR.absolute()))

from terminations.termination_base import TerminationBase


class ContinuouselyMoveAwayTermination(TerminationBase):
    def __init__(self,
        time_window: float=2.,
        ignore_phi_error: float=1.,
        ignore_theta_error: float=1.,
        termination_reward: float=-1.,
        is_termination_reward_based_on_steps_left: bool=False,
        env_config: dict=None,
        my_logger: logging.Logger=None
    ) -> None:
        super().__init__(
            termination_reward=termination_reward, 
            is_termination_reward_based_on_steps_left=is_termination_reward_based_on_steps_left,
            env_config=env_config,
            my_logger=my_logger
        )

        self.time_window = time_window
        self.ignore_phi_error = ignore_phi_error
        self.ignore_theta_error = ignore_theta_error

        self.prev_phi_errors = -360.
        self.phi_continuously_increasing_num = -1
        self.prev_theta_errors = -360.
        self.theta_continuously_increasing_num = -1

    
    def _get_termination(self, state: namedtuple, goal_v: float, goal_phi: float, goal_theta: float):
        tmp_phi_error = abs(goal_phi - state.phi)
        cur_phi_error = min(tmp_phi_error, 360. - tmp_phi_error)

        cur_theta_error = abs(goal_theta - state.theta)

        if cur_phi_error <= self.ignore_phi_error:
            self.phi_continuously_increasing_num = 0
        else:
            self.phi_continuously_increasing_num = 0 if cur_phi_error <= self.prev_phi_errors else self.phi_continuously_increasing_num + 1
        
        if cur_theta_error <= self.ignore_theta_error:
            self.theta_continuously_increasing_num = 0
        else:
            self.theta_continuously_increasing_num = 0 if cur_theta_error <= self.prev_theta_errors else self.theta_continuously_increasing_num + 1
        
        self.prev_phi_errors, self.prev_theta_errors = cur_phi_error, cur_theta_error

        if self.phi_continuously_increasing_num >= self.time_window_step_length and \
            self.theta_continuously_increasing_num >= self.time_window_step_length:

            if self.logger is not None:
                self.logger.info(f"phi and theta both change larger continously for {self.time_window_step_length} steps!!!")
            
            terminated, truncated = True, False

        else:
            terminated, truncated = False, False

        return terminated, truncated
    
    def get_termination(self, state: namedtuple, **kwargs) -> Tuple[bool, bool]:
        assert "goal_v" in kwargs, "args must include goal_v"
        assert "goal_phi" in kwargs, "args must include goal_phi"
        assert "goal_theta" in kwargs, "args must include goal_theta"

        return self._get_termination(
            state=state, 
            goal_v=kwargs["goal_v"], 
            goal_phi=kwargs["goal_phi"], 
            goal_theta=kwargs["goal_theta"]
        )
    
    def get_termination_and_reward(self, state: namedtuple, **kwargs) -> Tuple[bool, bool, float]:
        assert "goal_v" in kwargs, "args must include goal_v"
        assert "goal_phi" in kwargs, "args must include goal_phi"
        assert "goal_theta" in kwargs, "args must include goal_theta"
        assert "step_cnt" in kwargs, "args must include step_cnt"

        terminated, truncated = self._get_termination(
            state=state,
            goal_v=kwargs["goal_v"], 
            goal_phi=kwargs["goal_phi"], 
            goal_theta=kwargs["goal_theta"]
        )
        # reward = self.termination_reward if terminated else 0.

        return terminated, truncated, self.get_termination_penalty(terminated=terminated, steps_cnt=kwargs["step_cnt"])

    def reset(self):
        self.prev_phi_errors = -360.
        self.phi_continuously_increasing_num = -1
        self.prev_theta_errors = -360.
        self.theta_continuously_increasing_num = -1

    @property
    def time_window_step_length(self) -> int:
        return round(self.time_window * self.step_frequence)

    def __str__(self) -> str:
        return "continuousely_move_away_termination_based_on_phi_error_and_theta_error"